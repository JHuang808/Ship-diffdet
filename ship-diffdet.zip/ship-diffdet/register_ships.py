from detectron2.data import DatasetCatalog, MetadataCatalog
from detectron2.data.datasets import load_coco_json
import os
import sys


def register_ships_dataset():
    """
    注册船舶数据集
    完全依赖 DatasetCatalog 的状态判断，避免重复注册和重复打印
    在多进程环境下，每个进程都有独立的 DatasetCatalog，所以不打印消息
    """
    # 首先检查数据集是否已经在catalog中
    datasets_exist = "ships_train" in DatasetCatalog.list() and "ships_val" in DatasetCatalog.list()

    # 如果数据集已存在，直接返回，不打印任何消息
    # 这是关键：在多进程环境下（特别是 Windows 的 spawn 模式），
    # 每个进程都有独立的 DatasetCatalog，所以已存在时不需要任何操作
    if datasets_exist:
        return

    # 数据集不存在，需要注册（幂等操作）
    # 使用相对当前项目根目录的绝对路径，指向本仓库内的 ship/ 目录
    project_root = os.path.dirname(os.path.abspath(__file__))
    dataset_dir = os.path.join(project_root, "ship")
    train_json = os.path.join(dataset_dir, "annotations", "instances_train2017.json")
    train_imgs = os.path.join(dataset_dir, "train2017")
    val_json = os.path.join(dataset_dir, "annotations", "instances_val2017.json")
    val_imgs = os.path.join(dataset_dir, "val2017")

    # 注册训练集（幂等，再次检查以避免竞态条件）
    if "ships_train" not in DatasetCatalog.list():
        DatasetCatalog.register(
            "ships_train",
            lambda: load_coco_json(train_json, train_imgs)
        )
        MetadataCatalog.get("ships_train").set(
            thing_classes=["ship"],
            thing_dataset_id_to_contiguous_id={0: 0},
            evaluator_type="coco"
        )

    # 注册验证集（幂等，再次检查以避免竞态条件）
    if "ships_val" not in DatasetCatalog.list():
        DatasetCatalog.register(
            "ships_val",
            lambda: load_coco_json(val_json, val_imgs)
        )
        MetadataCatalog.get("ships_val").set(
            thing_classes=["ship"],
            thing_dataset_id_to_contiguous_id={0: 0},
            evaluator_type="coco"
        )

    # 注意：不在函数内部打印消息，避免多进程重复打印
    # 如果需要提示，应该在调用此函数的地方（且只在主进程中）打印

# 数据集注册函数已定义，由调用方决定何时执行